KPVBooklet for Kindle Touch and Kindle Paperwhite
=================================================

KPVBooklet is a Kindle booklet for starting KOReader/kindlepdfviewer.
It also updats last access and percentage finished information in Kindle's
content catalog entry of the opened document.

Supported firmware versions are:
	* Kindle Touch 5.1.2
	* Kindle Paperwhite 5.2.0
 	* Kindle Paperwhite 5.3.0
	* Kindle Paperwhite 5.3.1
	* Kindle Touch 5.3.2
	* Kindle Touch 5.3.2.1
	* Kindle Paperwhite 5.3.3
	* Kindle Paperwhite 5.3.4
	* Kindle Paperwhite 5.3.5
	* Kindle Paperwhite 5.3.6
	* Kindle Touch 5.3.7
	* Kindle Paperwhite 5.3.8
	* Kindle Paperwhite 5.3.9
	* Kindle Paperwhite 5.4.0(untested)
	* Kindle Paperwhite 5.4.2(untested)

KPVBooklet is licensed under the MIT license. See the file
LICENSE for more details.
